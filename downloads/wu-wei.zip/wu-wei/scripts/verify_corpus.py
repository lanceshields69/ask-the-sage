"""Check every key phrase in references/keywords.json against the public-domain
Chinese text (Project Gutenberg #7337), and optionally write chapters.json.

Usage:
  python scripts/verify_corpus.py            # verify
  python scripts/verify_corpus.py --write    # verify and save references/chapters.json
"""
import json, re, sys, urllib.request
from pathlib import Path

URL = "https://www.gutenberg.org/cache/epub/7337/pg7337.txt"
ROOT = Path(__file__).resolve().parent.parent
PUNCT = re.compile(r"[\s，。﹔；：？！「」『』、．・,.;:?!\"']")
NUM = {"一":1,"二":2,"三":3,"四":4,"五":5,"六":6,"七":7,"八":8,"九":9}

def cn_num(s):
    if s == "十": return 10
    if s.startswith("十"): return 10 + NUM[s[1]]
    if "十" in s:
        a, _, b = s.partition("十")
        return NUM[a] * 10 + (NUM[b] if b else 0)
    return NUM[s]

def chapters():
    raw = urllib.request.urlopen(URL, timeout=30).read().decode("utf-8")
    body = raw.split("*** START OF")[1].split("*** END OF")[0]
    parts = re.split(r"第([一二三四五六七八九十]+)章", body)
    out = {}
    for i in range(1, len(parts), 2):
        text = parts[i + 1].split("老子德經")[0]
        out[cn_num(parts[i])] = "".join(text.split())
    assert sorted(out) == list(range(1, 82)), "expected 81 chapters"
    return out

def main():
    chs = chapters()
    data = json.loads((ROOT / "references/keywords.json").read_text(encoding="utf-8"))
    bad = []
    for e in data["entries"]:
        phrase = PUNCT.sub("", e["key_phrase_zh"])
        if phrase not in PUNCT.sub("", chs[e["chapter"]]):
            bad.append(f'{e["id"]}: {e["key_phrase_zh"]} not found in chapter {e["chapter"]}')
    covered = {e["chapter"] for e in data["entries"]}
    missing = sorted(set(range(1, 82)) - covered)
    print(f'{len(data["entries"]) - len(bad)}/{len(data["entries"])} phrases verified')
    if missing: print("Chapters without an entry:", missing)
    for b in bad: print("MISMATCH", b)
    if "--write" in sys.argv:
        (ROOT / "references/chapters.json").write_text(
            json.dumps({"source": URL, "chapters": {str(k): v for k, v in sorted(chs.items())}},
                       ensure_ascii=False, indent=1), encoding="utf-8")
        print("Wrote references/chapters.json")
    sys.exit(1 if bad or missing else 0)

if __name__ == "__main__":
    main()
