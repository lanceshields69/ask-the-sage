# Keyword tagging schema

How the wisdom is stored: all 81 chapters, 85 entries.

## The idea

Each entry holds one **key phrase**: a short, verbatim line of the original Chinese that carries the chapter's teaching. Everything else in the entry (pinyin, gloss, tags) exists to make that phrase findable and quotable. A chapter can have more than one entry; most will have one or two.

## Fields

| Field | Required | Rules |
|---|---|---|
| `id` | yes | `ch{NN}-{handle-slug}`, e.g. `ch15-muddy-water`. Stable forever; logs reference it. |
| `chapter` | yes | 1–81, received (Wang Bi) numbering. |
| `key_phrase_zh` | yes | Verbatim from the received text, traditional characters. 3–16 characters. Must stand alone as a sentence or clause. |
| `pinyin` | yes | Tone-marked, matching the phrase character for character. |
| `gloss` | yes | Your own literal rendering, one sentence, under 20 words. Never copied from a modern translation (Le Guin, Mitchell, Addiss & Lombardo and others are under copyright). Public-domain Legge (1891) may be stored separately in `legge` if wanted. |
| `handle` | yes | 2–4 word English name people can say out loud: "the small fish", "muddy water". This is what makes the phrase memorable and shareable. |
| `keywords` | yes | 3–6 lowercase search terms, mixing the teaching ("yield") with the modern situation ("reply-all", "subscription"). The second kind is what lets an agent find the phrase from a real action. |
| `principle` | yes | Exactly one, from the taxonomy below. |
| `verdict_bias` | yes | Must equal the principle's default verdict. |
| `use_when` | yes | One sentence describing the agent situation where this phrase is the right reason. Write it in terms of actions, not philosophy. |
| `teaching` | yes | Plain, modern meaning in one or two sentences, under 40 words. Everyday language, no jargon, no preaching. |
| `voice` | yes | One line in the sage's tone, under 20 words: terse, paradoxical, nature imagery. Original writing; avoid echoing the chapter's own lines so it never reads as a quote, and avoid echoing modern translations. Always labeled as interpretation. |
| `legge` | no | The matching public-domain Legge sentence, if added from a verified source. |

## Principle taxonomy

| Principle | Verdict bias | Rubric question |
|---|---|---|
| timing | act | Is it small and timely? |
| stillness | wait | Will it resolve on its own? |
| sufficiency | release | Is it more than enough? |
| non-forcing | simplify | Does it force or escalate? |
| not-knowing | wait | Am I sure what's wanted? |
| subtraction | release | Can this be removed instead of added? |
| emptiness | simplify | Would less of it work better? |
| yielding | simplify | Is there a softer way through? |
| light-touch | wait | Am I stirring too often? |
| invisibility | act | Can this be done quietly, without credit? |

Two principles bias toward **act** on purpose. The Tao is not against doing; it is against forcing. A corpus where every phrase says "don't" would make the agent useless.

## Coverage and balance (v0.3)

Every chapter has at least one entry; chapters 9, 29, 63 and 81 have two because each holds two distinct teachings an agent needs.

| Principle | Entries | Verdict bias |
|---|---|---|
| invisibility | 13 | act |
| stillness | 11 | wait |
| non-forcing | 10 | simplify |
| not-knowing | 9 | wait |
| yielding | 9 | simplify |
| emptiness | 9 | simplify |
| sufficiency | 8 | release |
| light-touch | 6 | wait |
| subtraction | 5 | release |
| timing | 5 | act |

Verdicts: 28 simplify, 26 wait, 18 act, 13 release. No principle exceeds 16% of entries, and 21% lean toward **act**.

The cosmological chapters (1, 4, 6, 21, 25, 40, 42) were the hardest to map. Each was given the line in it that still changes a real action, rather than its most famous line.

## Adding or retagging entries

1. Write `use_when` first. If you can't describe a concrete agent situation, the phrase doesn't belong.
2. Pick the shortest phrase that carries the teaching. Shorter quotes travel further.
3. Keep the balance rules: no principle above about 20% of entries, at least 15% biased toward **act**.
4. Never change an existing `id`; restraint logs point to it.

## Verification

The source is Project Gutenberg eBook #7337, a public-domain copy of the received Chinese text. All 85 key phrases were checked against it by hand, and characters follow that edition (于 rather than 於, 朴 rather than 樸, 跡 rather than 迹).

Run `python scripts/verify_corpus.py` on any machine with internet access to re-check every phrase automatically; add `--write` to save the full text of all 81 chapters to `references/chapters.json` for the MCP server.

Known issues in the source:
- Chapter 64 reads 為者拜之 where other editions have 為者敗之. The same line appears correctly in chapter 29, so the "grasp and lose" entry is filed under 29.
- Editions differ in places (the Mawangdui and Guodian manuscripts most of all), so if you switch sources, re-run the script.

Still worth doing before launch: have a Chinese reader review the pinyin and glosses.
