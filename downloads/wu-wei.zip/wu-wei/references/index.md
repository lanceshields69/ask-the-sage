# The 81 chapters, by key phrase

Generated from `keywords.json`. Each entry: the quote (verbatim Chinese and a literal gloss), the plain teaching, and a line in the sage's voice. The voice lines are interpretation, not quotation.

This is a way into the Tao Te Ching, not a replacement for it. Read the whole book too.

## 1. The unnamed way

道可道，非常道 *dào kě dào, fēi cháng dào*  
"A way that can be put into words is not the constant Way."

Words and labels are useful, but they never capture the whole of a living situation. Hold your categories loosely.

*In the sage's voice:* Name the river, and it keeps flowing past the name.

## 2. The wordless teaching

行不言之教 *xíng bù yán zhī jiào*  
"Practice the teaching that uses no words."

People learn more from what you do than from what you explain. Let the work itself make the case.

*In the sage's voice:* The orchard does not argue for its fruit.

## 3. No exalting

不尚賢，使民不爭 *bù shàng xián, shǐ mín bù zhēng*  
"Do not exalt the talented, and people will not compete."

Put some people on a pedestal and you teach everyone else to compete for it. Praise the work, not the ranking.

*In the sage's voice:* Hang a prize in the village, and neighbors become rivals.

## 4. Blunt the edge

挫其銳，解其紛 *cuò qí ruì, jiě qí fēn*  
"Blunt the sharpness; untangle the knots."

Sharp words cut both ways, and knots tighten when pulled. Soften the edge first, then untangle patiently.

*In the sage's voice:* A blade kept too sharp soon chips. A knot yanked hard only tightens.

## 5. Keep to the center

多言數窮，不如守中 *duō yán shuò qióng, bù rú shǒu zhōng*  
"Many words soon run dry; better to keep to the center."

The more you say, the sooner you run out of anything worth saying. Say the essential thing and stop.

*In the sage's voice:* A drum beaten all day says nothing. Strike once, and it is heard.

## 6. Use without strain

綿綿若存，用之不勤 *mián mián ruò cún, yòng zhī bù qín*  
"Barely there yet lasting; used, it never wears out."

What lasts is used gently. Push people or systems past their natural pace and they wear out.

*In the sage's voice:* The valley spring is never pumped, and so it never runs dry.

## 7. Last and so first

後其身而身先 *hòu qí shēn ér shēn xiān*  
"Puts themselves last and so ends up first."

Putting others first often serves you best in the end. Demanding to go first usually costs more than it gains.

*In the sage's voice:* The one who steps aside finds the road open.

## 8. Like water

上善若水 *shàng shàn ruò shuǐ*  
"The highest good is like water."

Water helps everything and fights nothing, yet nothing wears down stone better. Find the way around rather than through.

*In the sage's voice:* Water does not argue with the rock. Give it a hundred years.

## 9. The full cup

持而盈之，不如其已 *chí ér yíng zhī, bù rú qí yǐ*  
"Holding it and filling it to the brim is not as good as stopping."

Past a certain point, adding more makes things worse, not better. Recognize enough, and stop there.

*In the sage's voice:* Fill the cup to the brim, and you can no longer carry it.

## 9. Work done, step back

功遂身退 *gōng suì shēn tuì*  
"The work done, step back."

When the work is done, let it stand without you. Taking a bow can undo what the work achieved.

*In the sage's voice:* The harvest is in. The farmer goes home.

## 10. Give without possessing

生而不有 *shēng ér bù yǒu*  
"Bring it to life without possessing it."

Make things for others, then let them go. Holding on to control turns a gift into a leash.

*In the sage's voice:* The tree drops its seed and does not follow it.

## 11. The empty vessel

當其無，有器之用 *dāng qí wú, yǒu qì zhī yòng*  
"In its emptiness lies the vessel's use."

The usefulness of a thing often lies in its empty space. Leave room, and what you make can hold more.

*In the sage's voice:* The bowl is clay, but we drink from the hollow.

## 12. Five colors

五色令人目盲 *wǔ sè lìng rén mù máng*  
"The five colors blind the eye."

Too many options, alerts, and colors overwhelm the senses until nothing registers. Less stimulation means clearer sight.

*In the sage's voice:* Show the eye every color, and it sees none.

## 13. Favor and disgrace

寵辱若驚 *chǒng rǔ ruò jīng*  
"Favor and disgrace alike are startling."

Praise and criticism both knock you off balance. Let either one settle before you respond.

*In the sage's voice:* Applause and jeers are the same wind. Let the reed bend, then stand.

## 14. The old way

執古之道，以御今之有 *zhí gǔ zhī dào, yǐ yù jīn zhī yǒu*  
"Hold to the ancient Way to manage what is here now."

Most new problems have old answers. Before inventing a process, check what has already worked.

*In the sage's voice:* The new path is often the old one, overgrown.

## 15. Muddy water

孰能濁以靜之徐清 *shú néng zhuó yǐ jìng zhī xú qīng*  
"Who can take muddy water and, through stillness, let it slowly clear?"

When things are stirred up, acting makes them murkier. Wait, and clarity comes on its own.

*In the sage's voice:* Do not reach into muddy water. Be still, and it clears for you.

## 16. Reckless action

不知常，妄作凶 *bù zhī cháng, wàng zuò xiōng*  
"Not knowing the constant, acting recklessly: misfortune."

Acting before you understand how things normally go is how mistakes happen. Learn the pattern first.

*In the sage's voice:* Plant before you know the seasons, and the frost will teach you.

## 17. Barely known

太上，下不知有之 *tài shàng, xià bù zhī yǒu zhī*  
"The best rulers: those below barely know they exist."

The best leaders are barely noticed. When things go well, people feel they did it themselves.

*In the sage's voice:* The best ruler is like soil: walked on, unseen, feeding everything.

## 18. When rules appear

大道廢，有仁義 *dà dào fèi, yǒu rén yì*  
"When the great Way is lost, rules of kindness and duty appear."

Rules multiply when trust breaks down. Before adding a policy, ask what trust was lost and repair that.

*In the sage's voice:* No one posts a sign saying 'be kind' in a kind house.

## 19. Fewer wants

少私寡欲 *shǎo sī guǎ yù*  
"Lessen the self; reduce wants."

Many purchases come from wanting, not needing. Wanting less is a quieter, steadier kind of wealth.

*In the sage's voice:* The one who wants little is never robbed.

## 20. Yes and yeah

唯之與阿，相去幾何 *wéi zhī yǔ ē, xiāng qù jǐ hé*  
"Between a polite yes and a casual yeah, how much difference?"

Many differences we fight over are tiny. Before re-editing or arguing, ask whether the change truly matters.

*In the sage's voice:* Yes or yeah, the door still opens.

## 21. Elusive and vague

道之為物，惟恍惟惚 *dào zhī wéi wù, wéi huǎng wéi hū*  
"The Way as a thing is elusive, indistinct."

Some things are genuinely unclear, and pretending otherwise leads you astray. Hold uncertain evidence lightly.

*In the sage's voice:* In the mist, the wise walk slowly and do not name the shapes.

## 22. Bend and be whole

曲則全 *qū zé quán*  
"Bend, and be whole."

Giving way on a small point can keep the whole thing intact. Flexibility is a strength, not a defeat.

*In the sage's voice:* The bamboo bends in the storm. The oak lies across the road.

## 23. The passing storm

飄風不終朝，驟雨不終日 *piāo fēng bù zhōng zhāo, zhòu yǔ bù zhōng rì*  
"A whirlwind does not last the morning; a downpour does not last the day."

Urgent feelings, like storms, rarely last. Much of what feels pressing passes on its own.

*In the sage's voice:* Even heaven cannot make a storm last the day.

## 24. On tiptoe

企者不立，跨者不行 *qǐ zhě bù lì, kuà zhě bù xíng*  
"Who stands on tiptoe cannot stand firm; who overstrides cannot walk."

Overreaching makes you unsteady. Promise what you can carry, and walk at a pace you can keep.

*In the sage's voice:* Reach too high and you fall. Stride too long and you stumble.

## 25. What is so of itself

道法自然 *dào fǎ zì rán*  
"The Way follows what is so of itself."

Things grow best according to their own nature. Support that growth instead of forcing a shape onto it.

*In the sage's voice:* No one pulls the shoot to make it grow.

## 26. Stillness masters haste

重為輕根，靜為躁君 *zhòng wéi qīng gēn, jìng wéi zào jūn*  
"The heavy is root of the light; stillness is master of haste."

Calm is what keeps haste from running the show. When there is no real deadline, slow down.

*In the sage's voice:* The rider who hurries loses the road. The one who sits steady arrives.

## 27. No tracks

善行，無轍跡 *shàn xíng, wú zhé jì*  
"Good walking leaves no tracks."

Good work leaves no mess behind it. Clean up after yourself so the result stands without side effects.

*In the sage's voice:* The bird crosses the sky and leaves no trail.

## 28. The uncarved block

復歸于朴 *fù guī yú pǔ*  
"Return to the uncarved block."

Every commitment carves you into a narrower shape. Undoing some returns you to simplicity and possibility.

*In the sage's voice:* Before the knife, the wood could become anything.

## 29. Drop the extreme

去甚，去奢，去泰 *qù shèn, qù shē, qù tài*  
"Drop the extreme, the extravagant, the excessive."

Most things go wrong at the extremes. Choose the plain version over the lavish or excessive one.

*In the sage's voice:* Take away the gold leaf, and the bowl still holds rice.

## 29. Grasp and lose

為者敗之，執者失之 *wéi zhě bài zhī, zhí zhě shī zhī*  
"Those who force it spoil it; those who grasp it lose it."

The harder you force an outcome, the more likely you spoil it. The tighter you grip, the more slips away.

*In the sage's voice:* Close your fist on water, and it is gone.

## 30. It comes back

其事好還 *qí shì hǎo huán*  
"Such deeds tend to come back."

Force invites force in return. Pressure applied today often comes back as pushback tomorrow.

*In the sage's voice:* Push the swing hard, and it returns harder.

## 31. Calm restraint

恬淡為上 *tián dàn wéi shàng*  
"Calm restraint is best."

Threats and ultimatums are tools of last resort. Even when they are needed, use them calmly and without pride.

*In the sage's voice:* Keep the sword in its sheath. If you must draw it, draw it with sorrow.

## 32. Settles evenly

民莫之令而自均 *mín mò zhī lìng ér zì jūn*  
"No one orders it, yet it settles evenly."

Left alone, people and work often find their own balance. Not everything needs to be assigned or arranged.

*In the sage's voice:* No one divides the rain, yet every field is watered.

## 33. Know yourself

知人者智，自知者明 *zhī rén zhě zhì, zì zhī zhě míng*  
"Knowing others is wisdom; knowing yourself is clarity."

Understanding others is useful; understanding yourself is clarity. Check your own assumptions before judging theirs.

*In the sage's voice:* Polish your own mirror before reading another's face.

## 34. Never claims greatness

以其終不自為大，故能成其大 *yǐ qí zhōng bù zì wéi dà, gù néng chéng qí dà*  
"Because it never makes itself great, it can achieve greatness."

Real achievement doesn't need to announce itself. Share results plainly and let them speak.

*In the sage's voice:* The river feeds the valley and never says so.

## 35. Music and bait

樂與餌，過客止 *yuè yǔ ěr, guò kè zhǐ*  
"Music and treats make the passing guest stop."

Hooks and gimmicks catch attention for a moment, then lose it. Lasting interest comes from substance.

*In the sage's voice:* The traveler stops for the drum, then walks on. The well keeps them returning.

## 36. Hidden tools

國之利器，不可以示人 *guó zhī lì qì bù kě yǐ shì rén*  
"A state's sharpest tools should not be shown."

Not every advantage needs to be revealed. Keep your leverage and fallback quiet unless showing them helps.

*In the sage's voice:* A wise host keeps the storehouse closed and the table open.

## 37. Nothing left undone

道常無為而無不為 *dào cháng wú wéi ér wú bù wéi*  
"The Way never forces, yet nothing is left undone."

Much gets done without your intervention. Trust the people and processes that are already working.

*In the sage's voice:* The seasons turn without a hand on the wheel.

## 38. Virtue without display

上德不德，是以有德 *shàng dé bù dé, shì yǐ yǒu dé*  
"High virtue does not display virtue, and so has it."

Goodness that performs for an audience loses something. Act on your values instead of announcing them.

*In the sage's voice:* The kind act is quiet. The kind speech is loud.

## 39. The low as base

貴以賤為本，高以下為基 *guì yǐ jiàn wéi běn, gāo yǐ xià wéi jī*  
"The noble takes the humble as root; the high takes the low as base."

Every high thing rests on a low foundation. Work with the people closest to the problem before going over their heads.

*In the sage's voice:* The mountain stands on the plain beneath it.

## 40. Reversal

反者道之動 *fǎn zhě dào zhī dòng*  
"Reversal is how the Way moves."

Things tend to turn around at their peak. Don't assume today's trend will simply continue.

*In the sage's voice:* The tide at its highest is already going out.

## 41. Late vessel

大器晚成 *dà qì wǎn chéng*  
"The great vessel is finished late."

Important things take longer than we want. Rushing them to finish usually makes them smaller.

*In the sage's voice:* The great bell is cast slowly. The cheap one rings by morning.

## 42. Add by subtracting

物或損之而益，或益之而損 *wù huò sǔn zhī ér yì, huò yì zhī ér sǔn*  
"Things may gain by being reduced, or lose by being added to."

Sometimes removing something makes the whole better, and adding makes it worse. Ask which this is.

*In the sage's voice:* Prune the vine, and the grapes grow sweeter.

## 43. Softest over hardest

天下之至柔，馳騁天下之至堅 *tiān xià zhī zhì róu, chí chěng tiān xià zhī zhì jiān*  
"The softest thing in the world gallops through the hardest."

Gentle persistence gets through where force fails. The soft approach often wins the long game.

*In the sage's voice:* The root splits the boulder without a sound.

## 44. Know enough

知足不辱，知止不殆 *zhī zú bù rǔ, zhī zhǐ bù dài*  
"Know what is enough and avoid disgrace; know when to stop and avoid danger."

Knowing you have enough protects you from regret; knowing when to stop protects you from harm.

*In the sage's voice:* The traveler who knows when to rest reaches home.

## 45. Skill looks clumsy

大巧若拙 *dà qiǎo ruò zhuō*  
"Great skill looks clumsy."

True mastery often looks plain, even awkward. Stop polishing once it works.

*In the sage's voice:* The finest potter leaves the thumbprint in the clay.

## 46. Never enough

禍莫大于不知足 *huò mò dà yú bù zhī zú*  
"No calamity is greater than not knowing what is enough."

Not knowing what is enough is the root of most trouble. Keep the scope tied to the actual goal.

*In the sage's voice:* The one who wants the whole river drowns in it.

## 47. The farther, the less

其出彌遠，其知彌少 *qí chū mí yuǎn, qí zhī mí shǎo*  
"The farther one goes, the less one knows."

More searching doesn't always mean more understanding. Often the answer is already within reach.

*In the sage's voice:* The one who chases every road never learns the one beneath their feet.

## 48. Daily subtraction

為學日益，為道日損 *wéi xué rì yì, wéi dào rì sǔn*  
"Learning adds something each day; the Way lets something go each day."

Learning is about adding; wisdom is about letting go. Each day, find one thing to drop.

*In the sage's voice:* Each day, set one stone down. The road grows lighter.

## 49. The people's mind

聖人常無心，以百姓心為心 *shèng rén cháng wú xīn, yǐ bǎi xìng xīn wéi xīn*  
"The sage keeps no mind of their own and makes the people's mind their own."

A good guide sets aside their own agenda and takes up the needs of the people they serve.

*In the sage's voice:* The valley has no shape of its own. It holds whatever river comes.

## 50. No ground for harm

以其無死地 *yǐ qí wú sǐ dì*  
"Because they leave no ground where death can enter."

A small precaution now can remove a serious risk later. Leave no opening for disaster.

*In the sage's voice:* The careful walker lights the lamp before nightfall.

## 51. Lead without lording

長而不宰 *zhǎng ér bù zǎi*  
"Lead without lording over."

Help things grow without controlling them. Let people make the decisions that belong to them.

*In the sage's voice:* The gardener waters the plant and lets it find its own way to the light.

## 52. Seeing the small

見小曰明 *jiàn xiǎo yuē míng*  
"Seeing the small is called clarity."

Clarity is noticing small things early. A small problem caught now costs little to fix.

*In the sage's voice:* The crack in the dam is smallest on the first day.

## 53. Side paths

大道甚夷，而人好徑 *dà dào shèn yí, ér rén hào jìng*  
"The great Way is level, yet people love side paths."

The straightforward route is usually open, yet we love clever shortcuts. Take the plain path when it's there.

*In the sage's voice:* The clever cut through the thorns while the open road waits.

## 54. Well planted

善建者不拔 *shàn jiàn zhě bù bá*  
"What is well planted cannot be uprooted."

What's built on solid foundations lasts. Doing it properly now saves rebuilding later.

*In the sage's voice:* Deep roots do not fear the wind.

## 55. Prime then old

物壯則老 *wù zhuàng zé lǎo*  
"What grows too forceful soon grows old."

Pushing growth or intensity past its natural point burns it out. Healthy things grow at their own pace.

*In the sage's voice:* The fire built too high is ash by midnight.

## 56. Those who know

知者不言，言者不知 *zhī zhě bù yán, yán zhě bù zhī*  
"Those who know do not say; those who say do not know."

Real understanding is often quiet, and loud certainty often hides gaps. Be careful with confident public claims.

*In the sage's voice:* The deep pool is silent. The shallow brook chatters.

## 57. They transform themselves

我無為，而民自化 *wǒ wú wéi, ér mín zì huà*  
"I do not force, and the people transform themselves."

People change best when given room, not pushed. Create space for change rather than driving it.

*In the sage's voice:* Stop pushing the boat, and the current carries it.

## 58. Fortune and misfortune

禍兮，福之所倚，福兮，禍之所伏 *huò xī, fú zhī suǒ yǐ, fú xī, huò zhī suǒ fú*  
"Misfortune is what fortune leans on; fortune is where misfortune hides."

Good news and bad news are often tangled together. Don't overreact to either before the story unfolds.

*In the sage's voice:* Lost horse, found horse: who can say which day was lucky?

## 59. Frugality

治人事天，莫若嗇 *zhì rén shì tiān, mò ruò sè*  
"In governing people and serving heaven, nothing beats frugality."

Using resources sparingly keeps reserves for when they matter. Conserve money, time, and energy as a habit.

*In the sage's voice:* The farmer who saves seed eats next year.

## 60. The small fish

治大國，若烹小鮮 *zhì dà guó, ruò pēng xiǎo xiān*  
"Govern a great state as you would cook a small fish."

Delicate things fall apart when handled too much. With a team, a deal, or a relationship, constant checking does more harm than leaving it be.

*In the sage's voice:* Turn the fish too often and it breaks. Leave it, and it cooks.

## 61. The lower stream

大國者下流 *dà guó zhě xià liú*  
"A great state is the lower stream."

When you hold the stronger position, take the lower, generous stance. The great draw others by being humble.

*In the sage's voice:* The big lake does not chase the streams. It lies low, and they come.

## 62. Why abandon them

人之不善，何棄之有 *rén zhī bù shàn, hé qì zhī yǒu*  
"Even when people are not good, why abandon them?"

Even people who fall short deserve another chance. Before closing a door for good, consider leaving it open.

*In the sage's voice:* The path does not refuse the one who stumbled on it.

## 63. While it's easy

圖難于其易 *tú nán yú qí yì*  
"Plan for the hard while it is still easy."

Hard problems start as easy ones. Deal with things while they're still small.

*In the sage's voice:* Pull the weed while it has two leaves.

## 63. Easy promises

夫輕諾必寡信 *fū qīng nuò bì guǎ xìn*  
"Easy promises earn little trust."

Promises made lightly are rarely kept. Commit to less and keep all of it.

*In the sage's voice:* A word given lightly floats away on the first breeze.

## 64. The first step

千里之行，始于足下 *qiān lǐ zhī xíng, shǐ yú zú xià*  
"A journey of a thousand li begins beneath your feet."

Every large goal starts with one small step. When stuck, take the smallest one in front of you.

*In the sage's voice:* The mountain is climbed one stone at a time, starting with this one.

## 65. Cleverness harms

以智治國，國之賊 *yǐ zhì zhì guó, guó zhī zéi*  
"Governing a state by cleverness harms it."

Clever tricks and spin erode trust. Plain dealing serves everyone better in the long run.

*In the sage's voice:* The clever trap catches the trapper too.

## 66. No weight felt

處上而民不重 *chǔ shàng ér mín bù zhòng*  
"It stays above, yet the people feel no weight."

Good leadership lifts burdens rather than adding them. People shouldn't feel the weight of whoever is in charge.

*In the sage's voice:* The bridge carries everyone and asks for nothing.

## 67. Frugal so generous

儉故能廣 *jiǎn gù néng guǎng*  
"Frugal, and therefore able to be generous."

Holding back on everyday spending leaves room to be generous where it counts.

*In the sage's voice:* The full granary feeds the village in winter.

## 68. Fight without anger

善戰者不怒 *shàn zhàn zhě bù nù*  
"The good fighter is not angry."

Anger makes you fight badly. If you must respond in a conflict, wait until you're calm.

*In the sage's voice:* The hand that strikes in anger misses.

## 69. Underestimating

禍莫大于輕敵 *huò mò dà yú qīng dí*  
"No calamity is greater than taking the opponent lightly."

Underestimating the other side is the costliest mistake. Assume they're thoughtful, and prepare accordingly.

*In the sage's voice:* The hunter who scorns the tiger becomes its supper.

## 70. Coarse cloth, jade inside

被褐而懷玉 *pī hè ér huái yù*  
"Wears coarse cloth, carries jade inside."

Substance matters more than packaging. The plain version that carries real value is often the right one.

*In the sage's voice:* The plainest box may hold the finest gift.

## 71. Know you don't know

知，不知，上矣 *zhī, bù zhī, shàng yǐ*  
"To know that you do not know is highest."

Recognizing the limits of your knowledge is the highest wisdom. When unsure what someone wants, ask.

*In the sage's voice:* The one who says 'I don't know' has already begun to learn.

## 72. Without display

自知不自見，自愛不自貴 *zì zhī bù zì xiàn, zì ài bù zì guì*  
"Know yourself without displaying yourself; value yourself without exalting yourself."

Know your worth without displaying it. Present yourself as you are, not as a monument.

*In the sage's voice:* The mountain does not stand on its toes.

## 73. Courage not to dare

勇于不敢則活 *yǒng yú bù gǎn zé huó*  
"Courage in not daring keeps you alive."

Holding back from a risky move can take more courage than making it. Boldness is not always bravery.

*In the sage's voice:* It takes one kind of courage to leap, and a rarer kind to stay.

## 74. The master carpenter

夫代大匠斲者，希有不傷其手矣 *fū dài dà jiàng zhuó zhě, xī yǒu bù shāng qí shǒu yǐ*  
"Whoever cuts in place of the master carpenter rarely avoids hurting their hand."

Doing an expert's job without their skill usually ends badly. Defer to the people whose work it truly is.

*In the sage's voice:* The apprentice who seizes the master's chisel learns by bleeding.

## 75. Meddling from above

民之難治，以其上之有為 *mín zhī nán zhì, yǐ qí shàng zhī yǒu wéi*  
"People are hard to govern because those above meddle."

Teams often struggle because of too much interference from above. The fix is usually less management, not more.

*In the sage's voice:* The more hands on the plow, the more crooked the furrow.

## 76. Soft and supple

柔弱者生之徒 *róu ruò zhě shēng zhī tú*  
"The soft and supple are companions of life."

Living things are flexible; rigid things are close to breaking. Soften your tone and stance to stay resilient.

*In the sage's voice:* The green branch bends. The dry one snaps.

## 77. From excess to lack

損有餘而補不足 *sǔn yǒu yú ér bǔ bù zú*  
"Take from what has excess and give to what lacks."

Nature evens things out, taking from surplus and filling what's lacking. Move what you have extra to where it's needed.

*In the sage's voice:* The flood fills the dry hollows first.

## 78. Accept the dirt

受國之垢，是謂社稷主 *shòu guó zhī gòu, shì wèi shè jì zhǔ*  
"Who takes on the state's disgrace is fit to rule it."

Owning a mistake plainly builds more trust than defending it. Taking responsibility is a form of strength.

*In the sage's voice:* The one who carries the blame is the one people follow.

## 79. The left tally

聖人執左契，而不責于人 *shèng rén zhí zuǒ qì, ér bù zé yú rén*  
"The sage holds the left tally yet makes no demands."

You can hold the record of what's owed without pressing for it. Not every debt needs chasing.

*In the sage's voice:* Keep the receipt. Let go of the grudge.

## 80. Unused tools

使有什伯之器而不用 *shǐ yǒu shí bó zhī qì ér bù yòng*  
"Let them have tools for many, yet not use them."

Having tools doesn't mean you must use them. Use only what the task truly needs.

*In the sage's voice:* The boat waits at the shore. Not every day needs a voyage.

## 81. True words

信言不美，美言不信 *xìn yán bù měi, měi yán bù xìn*  
"True words are not pretty; pretty words are not true."

Honest words are usually plain, and polished words often hide something. Choose truth over beauty.

*In the sage's voice:* The honest stone is rough. The painted one is hollow.

## 81. Act without contending

為而不爭 *wéi ér bù zhēng*  
"Act, and do not contend."

Do what's right without competing or proving a point. Act, and let the rest go.

*In the sage's voice:* The sun gives light and keeps no score.
